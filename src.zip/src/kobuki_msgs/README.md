kobuki_msgs
===========

**This repository is now legacy and in maintenance mode for ROS1 support. For the latest development (ROS2) releases, shift your xeyes to https://github.com/kobuki-base/kobuki_ros_interfaces.git.**

----
