^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package move_base_sequence
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.1 (2021-02-15)
------------------
* added a gif to readme
* edit2
* edit
* edited readme
* Edited Readme
* adjusted class, rosparams, ros topics names
* upload the package files
* Initial commit
* Contributors: Mark Naeem, MarkNaeem
