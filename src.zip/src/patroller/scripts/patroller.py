#!/usr/bin/env python
# license removed for brevity
__author__ = 'fiorellasibona'
import time
import rospy
import math

import actionlib
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus
from geometry_msgs.msg import Pose, Point, Quaternion
from tf.transformations import quaternion_from_euler

from leg_tracker.msg import PersonArray
from std_msgs.msg import String
from nav_msgs.msg import Odometry


class MoveBaseSeq():

    def __init__(self):

        self.persons_seen = []
        self.paused = True
        self.rotating = False
        self.odom_pose = None
        self.greet_people = True

        rospy.init_node('move_base_sequence')

        rospy.Subscriber("people_tracked", PersonArray, self.person_detected_cb)
        rospy.Subscriber('/odom', Odometry, self.update_odom)
        self.text_out = rospy.Publisher('/robot_face/text_out', String, queue_size=10)
        self.talking_finished = rospy.Publisher('/robot_face/talking_finished', String, queue_size=10)


        points_seq = rospy.get_param('patroller/p_seq')
        # Only yaw angle required (no ratotions around x and y axes) in deg:
        yaweulerangles_seq = rospy.get_param('patroller/yea_seq')
        #List of goal quaternions:
        quat_seq = list()
        #List of goal poses:
        self.pose_seq = list()
        self.goal_cnt = 0
        for yawangle in yaweulerangles_seq:
            #Unpacking the quaternion list and passing it as arguments to Quaternion message constructor
            quat_seq.append(Quaternion(*(quaternion_from_euler(0, 0, yawangle*math.pi/180, axes='sxyz'))))
        n = 3
        # Returns a list of lists [[point1], [point2],...[pointn]]
        points = [points_seq[i:i+n] for i in range(0, len(points_seq), n)]
        for point in points:
            #Exploit n variable to cycle in quat_seq
            self.pose_seq.append(Pose(Point(*point),quat_seq[n-3]))
            n += 1
        #Create action client
        self.client = actionlib.SimpleActionClient('move_base',MoveBaseAction)
        rospy.loginfo("Waiting for move_base action server...")
        wait = self.client.wait_for_server(rospy.Duration(5.0))
        if not wait:
            rospy.logerr("Action server not available!")
            rospy.signal_shutdown("Action server not available!")
            return
        rospy.loginfo("Connected to move base server")
        rospy.loginfo("Starting goals achievements ...")
        self.send_next_goal()
        rospy.spin()

    def update_odom(self, msg):
        self.odom_pose = msg.pose.pose

    def person_detected_cb(self, data):
        if self.paused :
            return
        if not self.greet_people:
            return
        
        if len(data.people) > 0 :
            if (data.people[0].id in self.persons_seen) :
                # rospy.loginfo("Old person with id " + str(data.people[0].id))
                return
            
            self.paused = True
            self.persons_seen.append(data.people[0].id)
            # rospy.loginfo(data.people[0].id)
            rospy.loginfo("New person detected, id "+str(data.people[0].id))
            rospy.loginfo("person x: "+str(data.people[0].pose.position.x)+", y: "+str(data.people[0].pose.position.y))
            self.client.cancel_goal()

            # self.rotate_to_person(data.people[0].pose)
            
            rospy.loginfo("Greeting")
            self.text_out.publish("Hello:) Person id "+str(data.people[0].id))
            time.sleep(5)
            self.talking_finished.publish("finished talking")
            rospy.loginfo("Have a nice day")
            self.text_out.publish("Have a nice day.")
            time.sleep(2)
            self.talking_finished.publish("finished talking")
            self.goal_cnt -= 1
            if self.goal_cnt == -1:
                self.goal_cnt = len(self.pose_seq) - 1
            self.goal_cnt %= len(self.pose_seq)
            self.send_next_goal()
            self.paused = False
            

    def active_cb(self):
        rospy.loginfo("Goal pose "+str(self.goal_cnt+1)+" is now being processed by the Action Server...")

    def feedback_cb(self, feedback):
        #To print current pose at each feedback:
        #rospy.loginfo("Feedback for goal "+str(self.goal_cnt)+": "+str(feedback))
        # rospy.loginfo("Feedback for goal pose "+str(self.goal_cnt+1)+" received")
        pass

    def done_rotating_cb(self, status, result):
        self.rotating = False
        rospy.loginfo("Stopped rotating")

    def done_cb(self, status, result):
        self.goal_cnt += 1
    # Reference for terminal status values: http://docs.ros.org/diamondback/api/actionlib_msgs/html/msg/GoalStatus.html
        if status == 2:
            rospy.loginfo("Goal pose "+str(self.goal_cnt)+" received a cancel request after it started executing, completed execution!")
            return

        if status == 3:
            rospy.loginfo("Goal pose "+str(self.goal_cnt)+" reached") 
            self.goal_cnt %= len(self.pose_seq) # keep going cyclically through all goals
            self.send_next_goal()
            return

        if status == 4:
            rospy.loginfo("Goal pose "+str(self.goal_cnt)+" was aborted by the Action Server")
            rospy.signal_shutdown("Goal pose "+str(self.goal_cnt)+" aborted, shutting down!")
            return

        if status == 5:
            rospy.loginfo("Goal pose "+str(self.goal_cnt)+" has been rejected by the Action Server")
            rospy.signal_shutdown("Goal pose "+str(self.goal_cnt)+" rejected, shutting down!")
            return

        if status == 8:
            rospy.loginfo("Goal pose "+str(self.goal_cnt)+" received a cancel request before it started executing, successfully cancelled!")
            return
        
        rospy.loginfo("Status is ", status)

    def send_next_goal(self):
        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now() 
        goal.target_pose.pose = self.pose_seq[self.goal_cnt]
        rospy.loginfo("Sending goal pose "+str(self.goal_cnt+1)+" to Action Server")
        rospy.loginfo(str(self.pose_seq[self.goal_cnt]))
        self.client.send_goal(goal, self.done_cb, self.active_cb, self.feedback_cb)
        self.paused = False

    def rotate_to_person(self, person_pose):
        self.rotating = True

        delta_x = person_pose.position.x - self.odom_pose.position.x
        delta_y = person_pose.position.y - self.odom_pose.position.y
        theta = math.atan(delta_y/delta_x)
        if delta_y < 0 :
            theta += math.pi
        rospy.loginfo("odom x: "+str(self.odom_pose.position.x)+", y: "+str(self.odom_pose.position.y))
        rospy.loginfo("theta = "+str(theta)+" rad = "+str(theta*180/math.pi)+" deg")

        goal = MoveBaseGoal()
        goal.target_pose.header.frame_id = "map"
        goal.target_pose.header.stamp = rospy.Time.now() 
        # goal.target_pose.pose = Pose(self.odom_pose.position, Quaternion(*(quaternion_from_euler(0, 0, 270*math.pi/180, axes='sxyz'))))
        goal.target_pose.pose = Pose(self.odom_pose.position, Quaternion(*(quaternion_from_euler(0, 0, theta, axes='sxyz'))))
        rospy.loginfo("Rotating to person")
        rospy.loginfo(goal.target_pose.pose)
        self.client.send_goal(goal, self.done_rotating_cb, None, None)

        while(self.rotating):
            time.sleep(1)
        

if __name__ == '__main__':
    try:
        MoveBaseSeq()
    except rospy.ROSInterruptException:
        rospy.loginfo("Navigation finished.")