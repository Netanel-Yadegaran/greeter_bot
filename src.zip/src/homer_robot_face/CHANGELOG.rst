^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package homer_robot_face
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.18 (2017-03-31)
-------------------
* bigger text size for expected input
* Contributors: Lisa

1.0.17 (2017-03-20)
-------------------

1.0.15 (2017-03-10)
-------------------
* expected input added to robot face
* right talking finished text output handleing
* smaller queue sizes
* Contributors: Florian Polster, Lisa

1.0.14 (2016-12-14)
-------------------
* fixed missing RenderSystem_GL error
* Contributors: Niklas Yann Wettengel

1.0.13 (2016-12-07)
-------------------
* latest changes from homer-repo
* Contributors: Niklas Yann Wettengel

1.0.11 (2016-12-06)
-------------------
* homer_robot_face: added homer_mary_tts dependency
* homer_robot_face: install everything
* Contributors: Niklas Yann Wettengel

1.0.10 (2016-11-17)
-------------------
* added libqt5x11extras5-dev dependency
* Contributors: Niklas Yann Wettengel

1.0.9 (2016-11-17)
------------------
* qt4->qt5 in package.xml
* Contributors: Niklas Yann Wettengel

1.0.8 (2016-11-15)
------------------
* fix?
* Contributors: Niklas Yann Wettengel

0.1.1 (2016-11-15)
------------------
* robot_face -> homer_robot_face
* Contributors: Niklas Yann Wettengel
